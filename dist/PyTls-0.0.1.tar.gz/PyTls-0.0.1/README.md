# Pyts

python工具合集，用来快速复用，极致执行

+ __init__.py
+ dictt.py
    + [get_map_value()](pyts/dictt.py#L12)
    字典迭代取值
    + [update_map_value()](pyts/dictt.py#L34)
    + [sort_map_key()](pyts/dictt.py#L60)
    + [sort_map_value()](pyts/dictt.py#64)
    字典排序
+ StrBuffer.py
参考java中的StringButter
    + [append()](pyts/StrBuffer.py#22)
    + [index_at()](pyts/StrBuffer.py#37)
    + [sort()](pyts/StrBuffer.py#47)
    + [reverse()](pyts/StrBuffer.py#50)
    + [char_at()](pyts/StrBuffer.py#53)
    + [to_str()](pyts/StrBuffer.py#58)
    + [storge()](pyts/StrBuffer.py#64)
+ strt.py
    + [str_reverse()](pyts/strt.py#14)
    + [str_repeat()](pyts/dictt.py#18)
    + [str_splits()](pyts/dictt.py#29)
    字符串批切割
+ typet.py
    + [is_none()](pyts/strt.py#11)
    + [is_type()](pyts/dictt.py#15)
    + [is_empty()](pyts/dictt.py#25)
    + [is_has_attr()](pyts/dictt.py#35)
+ loaddatat.py
    + [readbunchobj()](pyts/loaddatat.py#13)
    + [writebunchobj()](pyts/loaddatat.py#19)
    读存数据
+ randomt.py
    + [get_random()](pyts/randomt.py#32)
+ Chinese2num.py
数字相关，提取数字更加强大的功能建议参考[YMMNlpUtils](https://github.com/sladesha/machine_learning/blob/master/YMMNlpUtils/YMMNlpUtils/YMMNlpUtils.py)
    + [Chinese_2_num()](pyts/Chinese2num.py#20)
    + [ln()](pyts/Chinese2num.py#29)
    + [isdigit()](pyts/Chinese2num.py#33)
+ matht.py
    + [entropy()](pyts/matht.py#14)